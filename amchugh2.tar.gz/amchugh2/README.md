# cs320
Name:		Abigail McHugh
BU ID:		amchugh2
B Number:	B00682131

This project was interesting, but got stressful at the end. 1-4 were fairly easy to implement, but
I had trouble figuring out the logic for touranment, and especially BTB. I enjoyed it and I 
definitely learned a lot more about how branch predictors work!
